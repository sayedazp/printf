/**
 * constructor - Test function
 *
 * @path: Hello
 * @test: World
 *
 * Return: 0
 */
int constructor(char **path, int test)
{
	return (0);
}

/**
 * constructor - Test function
 *
 * @path: Hello
 * @test: World
 *
 * Return: 0
 */
int *constructor(char **path, int test)
{
	return ((int *)0);
}

/**
 * ructor - Test function
 *
 * @path: Hello
 * @test: World
 *
 * Return: 0
 */
int constructor(char **path, int test)
{
	return (0);
}

/**
 * ructor - Test function
 *
 * @path: Hello
 * @test: World
 *
 * Return: 0
 */
int *constructor(char **path, int test)
{
	return ((int *)0);
}