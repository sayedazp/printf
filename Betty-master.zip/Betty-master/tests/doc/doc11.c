binary_tree_t *binary_trees_ancestor(const binary_tree_t *,
	const binary_tree_t *);

/**
 * sample - Sample
 *
 * @tmp1: tmp1
 * @tmp2: tmp2
 *
 * Return: Test
 */
binary_tree_t *sample(const binary_tree_t *tmp1,
	const binary_tree_t *tmp2)
{
	return (NULL);
}
