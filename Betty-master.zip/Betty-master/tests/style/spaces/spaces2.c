char *func0(char *var)
{
	char *str;
	Struct_s *ptr;

	str = var;
	str = ptr->str;
	return (str);
}

char* func2(char* var)
{
	char* str;
	Struct_s* ptr;

	str = var;
	str = ptr-> str;
	str = ptr ->str;
	str = ptr -> str;
	return (str);
}
