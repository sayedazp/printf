EC_KEY *ec_from_pub(uint8_t const pub[EC_PUB_LEN])
{
	EC_KEY *key = NULL;
	EC_POINT *point = NULL;
	EC_GROUP const *group = NULL;
	int test_int = 0;

	return (key);
}
