/*
 * Fixed: token_t *token was detected as a global variable
 */

static const char *process_token(command_chain_t *chain, command_t **cmd,
	token_t *token, const char *start)
{
	return (NULL);
}

static command_t **alias_expand_command(shell_t *shell,
	command_t *command, char *used)
{
	return (NULL);
}
