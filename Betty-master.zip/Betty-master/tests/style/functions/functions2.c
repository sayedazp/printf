int func0(void)
{
	while (1)
	{
		while (1)
		{
			while (1)
			{
				while (1)
				{
					while (1)
					{
						return (1);
					}
				}
			}
		}
	}
}

int func1(void)
{
	for (; 1;)
	{
		for (; 1;)
		{
			for (; 1;)
			{
				for (; 1;)
				{
					for (; 1;)
					{
						return (1);
					}
				}
			}
		}
	}
}

int func2(void)
{
	{
		{
			{
				{
					{
						return (1);
					}
				}
			}
		}
	}
}
