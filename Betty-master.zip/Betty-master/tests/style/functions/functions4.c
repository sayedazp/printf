void func0(int var)
{
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	/* 10 */
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	/* 20 */
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	/* 30 */
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	/* 40 */
}

void func1(int var)
{
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	/* 10 */
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	/* 20 */
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	/* 30 */
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	++var;
	/* 40 */
	++var;
}
